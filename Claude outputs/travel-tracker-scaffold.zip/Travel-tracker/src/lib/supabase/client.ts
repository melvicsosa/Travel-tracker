"use client";

import { createBrowserClient } from "@supabase/ssr";

/** Browser-side Supabase client. One instance per tab is enough. */
export function createClient() {
  return createBrowserClient(
    process.env.NEXT_PUBLIC_SUPABASE_URL!,
    process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!,
  );
}
